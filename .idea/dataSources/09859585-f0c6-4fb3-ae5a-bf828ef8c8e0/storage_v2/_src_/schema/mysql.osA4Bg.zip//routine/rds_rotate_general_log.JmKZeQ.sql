create
    definer = rdsadmin@localhost procedure rds_rotate_general_log() deterministic reads sql data
BEGIN
  DECLARE sql_logging BOOLEAN;
  select @@sql_log_bin into sql_logging;
  set @@sql_log_bin=off;
  CREATE TABLE IF NOT EXISTS mysql.general_log_template LIKE mysql.general_log;
  CREATE TABLE IF NOT EXISTS mysql.general_log2 LIKE mysql.general_log_template;
  DROP TABLE IF EXISTS mysql.general_log_backup;
  RENAME TABLE mysql.general_log TO mysql.general_log_backup, mysql.general_log2 TO mysql.general_log;
  set @@sql_log_bin=sql_logging;
END;

