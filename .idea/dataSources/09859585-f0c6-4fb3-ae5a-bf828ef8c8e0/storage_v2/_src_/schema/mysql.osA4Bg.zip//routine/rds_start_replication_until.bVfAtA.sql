create
    definer = rdsadmin@localhost procedure rds_start_replication_until(IN replication_log_file text, IN replication_stop_point bigint)
BEGIN
    DECLARE v_mysql_version VARCHAR(20);
    DECLARE v_called_by_user VARCHAR(50);
    DECLARE v_replication_threads_running INT;
    DECLARE v_slave_parallel_workers INT;
    DECLARE sql_logging BOOLEAN;
    DECLARE v_precheck_passed BOOLEAN;
    DECLARE v_perf_schema_enabled BOOLEAN;

    SET v_precheck_passed = True;
    SELECT @@sql_log_bin INTO sql_logging;
    SET @@sql_log_bin = OFF;
    SELECT @@performance_schema INTO v_perf_schema_enabled;
    SELECT user() INTO v_called_by_user;
    SELECT version() INTO v_mysql_version;
    SELECT @@slave_parallel_workers into v_slave_parallel_workers;
 
    IF v_perf_schema_enabled = 1 THEN
        SELECT COUNT(1) INTO v_replication_threads_running FROM performance_schema.threads WHERE name = 'thread/sql/slave_io' OR name = 'thread/sql/slave_sql';
    ELSE
        SELECT COUNT(1) INTO v_replication_threads_running FROM information_schema.processlist WHERE user = 'system user';
    END IF;

    IF v_replication_threads_running > 0 THEN
        SELECT 'Replication is already running. Call mysql.rds_stop_replication to stop replication' AS Message;
        SET v_precheck_passed = False;
    END IF;
    IF v_precheck_passed = True AND v_slave_parallel_workers > 0 THEN
        SELECT 'rds_start_replication_until is not supported for multi-threaded slaves' AS Message;
        SET v_precheck_passed = False;
    END IF;
    IF v_precheck_passed = True AND (replication_log_file IS NULL OR TRIM(replication_log_file) = '') THEN
        SELECT 'Invalid input: replication_log_file cannot be NULL or empty' AS Message;
        SET v_precheck_passed = False;
    END IF;
    IF v_precheck_passed = True AND TRIM(replication_log_file) REGEXP '^.+\\.[0-9]+$' = 0 THEN
      SELECT 'Invalid input: invalid syntax for replication_log_file' AS Message;
      SET v_precheck_passed = False;
    END IF;
    IF v_precheck_passed = True AND (replication_stop_point IS NULL OR replication_stop_point <= 0 ) THEN
        SELECT 'Invalid input: replication_stop_point cannot be NULL, less than or equal to 0' AS Message;
        SET v_precheck_passed = False;
    END IF;
    
    IF v_precheck_passed = True THEN
        UPDATE mysql.rds_replication_status SET called_by_user = v_called_by_user, action = 'start slave until', mysql_version = v_mysql_version, replication_log_file = TRIM(replication_log_file), replication_stop_point = replication_stop_point, replication_gtid = NULL WHERE action IS NOT NULL;
        COMMIT;

        SET @cmd = CONCAT('START SLAVE UNTIL ', CONCAT_WS(', ', CONCAT('MASTER_LOG_FILE = "', TRIM(replication_log_file), '"'), CONCAT('MASTER_LOG_POS = ', replication_stop_point)));
        PREPARE rds_start_replication_until FROM @cmd;
        EXECUTE rds_start_replication_until;
        DEALLOCATE PREPARE rds_start_replication_until;

        INSERT INTO mysql.rds_history(called_by_user, action, mysql_version, master_log_file, master_log_pos) VALUES(v_called_by_user, 'start slave until', v_mysql_version, SUBSTRING(replication_log_file, 1, 50), replication_stop_point);
        COMMIT;
        
        SELECT CONCAT('Slave started until MASTER_LOG_FILE = "', TRIM(replication_log_file), '" and MASTER_LOG_POS = ', replication_stop_point) AS Message;
    END IF;

    SET @@sql_log_bin=sql_logging;
END;

